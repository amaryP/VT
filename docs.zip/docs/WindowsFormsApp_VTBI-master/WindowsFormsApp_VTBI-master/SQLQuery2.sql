﻿update dbo.TradeSet
set TypeTrade='STANDARD',CodeMethodeSuivi='TEST'
